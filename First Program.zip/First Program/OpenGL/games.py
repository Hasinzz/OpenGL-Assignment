"""
Catch the Diamonds!
Assignment 2 – Implementation using PyOpenGL and GLUT with DDA Line Drawing

This solution implements the game “Catch the Diamonds!” using OpenGL.
All shapes (diamond, catcher, and buttons) are drawn with a custom line drawing 
function based on the Digital Differential Analyzer (DDA) algorithm.

Requirements:
• A diamond falls from the top with a random horizontal position and random bright color.
• The catcher moves horizontally with left/right arrow keys; it turns red on game over.
• Catching a diamond increases the score; missing one ends the game.
• Three buttons are drawn using GL_POINTS:
    - Left arrow (teal): restart game.
    - Center (amber): toggle between play and pause.
    - Right (red cross): terminate the application.
• The falling diamond’s speed increases over time (using delta timing).
• Collision detection uses the AABB algorithm.
• All drawing must use our own midpoint line drawing algorithm (here using the DDA method).
"""

from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import sys
import time
import random

# ---------------- Global Game Settings and Variables -------------------
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

# Game states
STATE_PLAYING = 0
STATE_PAUSED = 1
STATE_GAMEOVER = 2

gameState = STATE_PLAYING
score = 0

# Delta timing globals
previous_time = 0

# Diamond settings
diamond_radius = 20
diamond_speed_initial = 100.0   # pixels per second at start
diamond_speed = diamond_speed_initial
diamond_acceleration = 10.0     # incremental speed per second
diamond_x = 0
diamond_y = WINDOW_HEIGHT - diamond_radius
diamond_color = (1.0, 1.0, 1.0)  # will be randomized on spawn

# Catcher settings (bowl at the bottom)
catcher_y = 50
catcher_width = 100  # overall horizontal span
catcher_height = 30  # vertical dimension
catcher_x = WINDOW_WIDTH // 2  # center position
catcher_color_normal = (1.0, 1.0, 1.0)  # white normally
catcher_color_gameover = (1.0, 0.0, 0.0)  # red when game over

# Buttons settings (positions and sizes)
button_size = 60
# Left button (restart): positioned at (50, WINDOW_HEIGHT - 50)
left_button = {'x': 50, 'y': WINDOW_HEIGHT - 50, 'size': button_size}
# Middle button (play/pause): centered at top middle
middle_button = {'x': WINDOW_WIDTH // 2, 'y': WINDOW_HEIGHT - 50, 'size': button_size}
# Right button (terminate): positioned at (WINDOW_WIDTH - 50, WINDOW_HEIGHT - 50)
right_button = {'x': WINDOW_WIDTH - 50, 'y': WINDOW_HEIGHT - 50, 'size': button_size}

# ---------------- DDA Line Drawing Function -------------------
def draw_line(x1, y1, x2, y2):
    """
    Draws a line from (x1, y1) to (x2, y2) using the DDA algorithm.
    The DDA algorithm calculates the required number of steps based on the maximum 
    difference in x or y, then increments by the computed fraction each step.
    Points are drawn using GL_POINTS.
    """
    # Calculate differences
    dx = x2 - x1
    dy = y2 - y1
    steps = int(max(abs(dx), abs(dy)))
    
    # Calculate increment in each axis for each step
    if steps == 0:
        # Single point, no need to iterate
        glBegin(GL_POINTS)
        glVertex2i(int(round(x1)), int(round(y1)))
        glEnd()
        return

    x_inc = dx / steps
    y_inc = dy / steps
    
    # Starting point
    x = x1
    y = y1
    glBegin(GL_POINTS)
    for _ in range(steps + 1):
        glVertex2i(int(round(x)), int(round(y)))
        x += x_inc
        y += y_inc
    glEnd()

# ---------------- Shape Drawing Functions -------------------
def draw_polygon(points):
    """
    Draws a polygon (closed shape) by drawing lines between consecutive vertices and closing the loop.
    Each edge is drawn using our DDA-based draw_line() function.
    """
    num_points = len(points)
    for i in range(num_points):
        x1, y1 = points[i]
        x2, y2 = points[(i+1) % num_points]
        draw_line(x1, y1, x2, y2)

def draw_diamond(cx, cy, r):
    """
    Draws a diamond shape centered at (cx, cy) with "radius" r.
    The diamond is drawn by connecting four vertices:
      top:    (cx, cy + r)
      right:  (cx + r, cy)
      bottom: (cx, cy - r)
      left:   (cx - r, cy)
    """
    vertices = [(cx, cy + r),
                (cx + r, cy),
                (cx, cy - r),
                (cx - r, cy)]
    draw_polygon(vertices)

def draw_catcher(cx, base_y, width, height, color):
    """
    Draws the catcher bowl using a four-line shape.
    The catcher is rendered as a trapezoidal bowl with vertices:
      left-bottom: (cx - width/2, base_y)
      top-left:    (cx - width/4, base_y + height)
      top-right:   (cx + width/4, base_y + height)
      right-bottom:(cx + width/2, base_y)
    """
    glColor3f(*color)
    vertices = [(cx - width/2, base_y),
                (cx - width/4, base_y + height),
                (cx + width/4, base_y + height),
                (cx + width/2, base_y)]
    draw_polygon(vertices)

def draw_left_button():
    """
    Draws the left button with a left arrow shape in bright teal.
    The arrow is rendered as a triangle using our DDA-based draw_line.
    """
    glColor3f(0.0, 0.8, 0.8)  # bright teal
    x = left_button['x']
    y = left_button['y']
    size = left_button['size']
    vertices = [(x - size/4, y),         # tip of arrow (pointing left)
                (x + size/4, y + size/4),  # top-right
                (x + size/4, y - size/4)]  # bottom-right
    draw_polygon(vertices)

def draw_middle_button():
    """
    Draws the middle button showing a play or pause icon in amber.
    If the game is paused, a play icon (triangle) is drawn.
    If the game is playing, a pause icon (two vertical bars) is drawn.
    """
    glColor3f(1.0, 0.75, 0.0)  # amber color
    x = middle_button['x']
    y = middle_button['y']
    size = middle_button['size']
    
    if gameState == STATE_PAUSED:
        # Draw a play icon (triangle pointing to the right)
        vertices = [(x - size/8, y - size/4),
                    (x - size/8, y + size/4),
                    (x + size/4, y)]
        draw_polygon(vertices)
    elif gameState == STATE_PLAYING:
        # Draw a pause icon (two vertical bars)
        left_bar = [(x - size/4, y - size/4),
                    (x - size/4, y + size/4),
                    (x - size/8, y + size/4),
                    (x - size/8, y - size/4)]
        right_bar = [(x + size/8, y - size/4),
                     (x + size/8, y + size/4),
                     (x + size/4, y + size/4),
                     (x + size/4, y - size/4)]
        draw_polygon(left_bar)
        draw_polygon(right_bar)
    else:
        # In game over state, we continue to show the play icon.
        vertices = [(x - size/8, y - size/4),
                    (x - size/8, y + size/4),
                    (x + size/4, y)]
        draw_polygon(vertices)

def draw_right_button():
    """
    Draws the right button in the shape of a cross, rendered in red.
    The cross is drawn with two intersecting lines.
    """
    glColor3f(1.0, 0.0, 0.0)  # red color
    x = right_button['x']
    y = right_button['y']
    size = right_button['size']
    # Diagonal from top-left to bottom-right
    draw_line(x - size/4, y + size/4, x + size/4, y - size/4)
    # Diagonal from bottom-left to top-right
    draw_line(x - size/4, y - size/4, x + size/4, y + size/4)

# ---------------- Collision Detection -------------------
def check_collision():
    """
    Checks for collision between the falling diamond and the catcher
    using AABB (Axis-Aligned Bounding Box) collision detection.
    """
    # Diamond’s AABB approximated as a square around the diamond
    d_left   = diamond_x - diamond_radius
    d_right  = diamond_x + diamond_radius
    d_top    = diamond_y + diamond_radius
    d_bottom = diamond_y - diamond_radius

    # Catcher’s AABB based on its defined shape:
    catcher_left   = catcher_x - catcher_width/2
    catcher_right  = catcher_x + catcher_width/2
    catcher_bottom = catcher_y
    catcher_top    = catcher_y + catcher_height

    return (d_left < catcher_right and
            d_right > catcher_left and
            d_bottom < catcher_top and
            d_top > catcher_bottom)

# ---------------- Game Logic Functions -------------------
def spawn_new_diamond():
    """Resets diamond parameters: random horizontal position, random bright color,
       and resets starting position and speed."""
    global diamond_x, diamond_y, diamond_color, diamond_speed
    diamond_x = random.randint(diamond_radius, WINDOW_WIDTH - diamond_radius)
    diamond_y = WINDOW_HEIGHT - diamond_radius
    # Random bright color (each channel at least 0.5)
    diamond_color = (random.uniform(0.5, 1.0),
                     random.uniform(0.5, 1.0),
                     random.uniform(0.5, 1.0))
    diamond_speed = diamond_speed_initial

def reset_game():
    """Resets the game state for a new game."""
    global score, gameState, catcher_x
    score = 0
    gameState = STATE_PLAYING
    catcher_x = WINDOW_WIDTH // 2
    spawn_new_diamond()
    print("Starting Over")

# ---------------- Callback Functions -------------------
def display():
    glClear(GL_COLOR_BUFFER_BIT)
    
    # Draw diamond (only when not in game-over state)
    if gameState != STATE_GAMEOVER:
        glColor3f(*diamond_color)
        draw_diamond(diamond_x, diamond_y, diamond_radius)
    
    # Draw catcher: red if game over, otherwise white.
    if gameState == STATE_GAMEOVER:
        cur_catcher_color = catcher_color_gameover
    else:
        cur_catcher_color = catcher_color_normal
    draw_catcher(catcher_x, catcher_y, catcher_width, catcher_height, cur_catcher_color)
    
    # Draw buttons
    draw_left_button()
    draw_middle_button()
    draw_right_button()
    
    glutSwapBuffers()

def update():
    global diamond_y, diamond_speed, score, gameState, previous_time
    current_time = time.time()
    if previous_time == 0:
        previous_time = current_time
    dt = current_time - previous_time
    previous_time = current_time

    if gameState == STATE_PLAYING:
        # Update diamond position with delta timing
        diamond_y -= diamond_speed * dt
        diamond_speed += diamond_acceleration * dt

        if check_collision():
            score += 1
            print("Score:", score)
            spawn_new_diamond()
        elif diamond_y < 0:
            gameState = STATE_GAMEOVER
            print("Game Over. Final Score:", score)
    
    glutPostRedisplay()

def special_keys(key, x, y):
    """
    Handles left/right arrow key presses to move the catcher.
    Movement is only allowed while the game is in PLAYING state.
    """
    global catcher_x
    step = 20  # pixels per key press
    if gameState != STATE_PLAYING:
        return
    if key == GLUT_KEY_LEFT:
        catcher_x -= step
        if catcher_x - catcher_width/2 < 0:
            catcher_x = catcher_width/2
    elif key == GLUT_KEY_RIGHT:
        catcher_x += step
        if catcher_x + catcher_width/2 > WINDOW_WIDTH:
            catcher_x = WINDOW_WIDTH - catcher_width/2

def mouse_click(button, state, x, y):
    """
    Handles mouse click events.
    Converts window coordinates to OpenGL coordinates and checks for button clicks.
    """
    global gameState
    if state != GLUT_DOWN:
        return

    # Convert y coordinate (OpenGL has origin at bottom-left)
    y = WINDOW_HEIGHT - y

    # Left button (restart game)
    if (abs(x - left_button['x']) < left_button['size']/2 and 
        abs(y - left_button['y']) < left_button['size']/2):
        reset_game()
        return

    # Middle button (toggle play/pause)
    if (abs(x - middle_button['x']) < middle_button['size']/2 and 
        abs(y - middle_button['y']) < middle_button['size']/2):
        if gameState == STATE_PLAYING:
            gameState = STATE_PAUSED
        elif gameState == STATE_PAUSED:
            gameState = STATE_PLAYING
        return

    # Right button (terminate game)
    if (abs(x - right_button['x']) < right_button['size']/2 and 
        abs(y - right_button['y']) < right_button['size']/2):
        print("Goodbye. Final Score:", score)
        glutLeaveMainLoop()
        return

def reshape(width, height):
    """
    Handles window reshape events.
    """
    global WINDOW_WIDTH, WINDOW_HEIGHT
    WINDOW_WIDTH = width
    WINDOW_HEIGHT = height
    glViewport(0, 0, width, height)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluOrtho2D(0, width, 0, height)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

def init():
    glClearColor(0.0, 0.0, 0.0, 1.0)  # Black background
    glPointSize(2.0)  # Set GL_POINTS size for our DDA drawing
    spawn_new_diamond()

# ---------------- Main Function -------------------
def main():
    global previous_time
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB)
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT)
    glutInitWindowPosition(100, 100)
    glutCreateWindow(b"Catch the Diamonds!")
    init()
    glutDisplayFunc(display)
    glutIdleFunc(update)
    glutReshapeFunc(reshape)
    glutSpecialFunc(special_keys)
    glutMouseFunc(mouse_click)
    previous_time = time.time()
    glutMainLoop()

if __name__ == '__main__':
    main()

