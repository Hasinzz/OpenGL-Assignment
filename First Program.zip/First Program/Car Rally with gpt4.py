from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import math
import random
import time

# Global Variables
cones = []  # Initialize cones list
camera_pos = [0, 20, 30]  # Adjusted camera position
fovY = 60
GRID_LENGTH = 600
rand_var = 423

# Car properties
car_pos = [0.0, 0.0]
car_angle = 0.0
car_speed = 0.0
max_speed = 2.0
acceleration = 0.05
friction = 0.02
steer_angle = 3.0

# Nitro Boost
boost_active = False
boost_bar = 100  # full = 100
boost_speed = 4.0

# Lap and checkpoints
lap_start_time = 0.0
current_lap_time = 0.0
best_lap_time = None
checkpoint_passed = 0
num_checkpoints = 5

# Game state
paused = False

# Key States
keys = {}

# Recording Positions (to store the path for ghost car)
recording_positions = []  # Initialize the recording_positions list

# ========== Helper Functions ==========

def draw_text(x, y, text, font=GLUT_BITMAP_HELVETICA_18):
    glColor3f(1, 1, 1)
    glMatrixMode(GL_PROJECTION)
    glPushMatrix()
    glLoadIdentity()

    gluOrtho2D(0, 1000, 0, 800)

    glMatrixMode(GL_MODELVIEW)
    glPushMatrix()
    glLoadIdentity()

    glRasterPos2f(x, y)
    for ch in text:
        glutBitmapCharacter(font, ord(ch))

    glPopMatrix()
    glMatrixMode(GL_PROJECTION)
    glPopMatrix()
    glMatrixMode(GL_MODELVIEW)

def setupCamera():
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()  # Reset the projection matrix
    gluPerspective(fovY, 1.25, 0.1, 1500)  # Adjust FOV for better scene perspective
    glMatrixMode(GL_MODELVIEW)  # Switch back to modelview matrix
    glLoadIdentity()  # Reset modelview matrix

    # Dynamically set camera position behind and above the car
    cx = car_pos[0] - 10 * math.sin(math.radians(car_angle))
    cy = car_pos[1] - 10 * math.cos(math.radians(car_angle))
    cz = 10  # Adjusted camera height

    gluLookAt(cx, cy, cz, car_pos[0], car_pos[1], 2, 0, 0, 1)

# Draw the track (with extended road length and proper boundaries)
def draw_track():
    # Road surface (black road)
    glColor3f(0.1, 0.1, 0.1)  # Black color for the road
    glBegin(GL_QUADS)
    glVertex3f(-100, -1, -200)
    glVertex3f(100, -1, -200)
    glVertex3f(100, -1, 200)
    glVertex3f(-100, -1, 200)
    glEnd()

    # Boundaries of the track (brown for barriers)
    glColor3f(0.5, 0.25, 0.0)  # Brown color for the boundary
    glLineWidth(3)  # Thicker boundary lines

    glBegin(GL_LINES)
    # Draw boundary lines
    glVertex3f(-100, -1, -200)
    glVertex3f(100, -1, -200)

    glVertex3f(100, -1, -200)
    glVertex3f(100, -1, 200)

    glVertex3f(100, -1, 200)
    glVertex3f(-100, -1, 200)

    glVertex3f(-100, -1, 200)
    glVertex3f(-100, -1, -200)
    glEnd()

    # Optional: Draw checkpoints as small cubes or spheres (for lap timing)
    for i in range(num_checkpoints):
        angle_rad = math.radians(360 / num_checkpoints * i)
        cx = 100 * math.cos(angle_rad)
        cy = 100 * math.sin(angle_rad)
        glPushMatrix()
        glTranslatef(cx, 0, cy)
        glScalef(10, 1, 2)
        glColor3f(1, 1, 0)  # Yellow checkpoints
        glutSolidCube(1)
        glPopMatrix()

# Drawing a car model (cube for body and cylinders for wheels)
def draw_car():
    # Body of the car (using a scaled cube)
    glPushMatrix()
    glTranslatef(car_pos[0], 0, car_pos[1])
    glRotatef(car_angle, 0, 1, 0)
    glScalef(5, 2, 8)  # Car size
    glColor3f(1, 0, 0)  # Red color for the body
    glutSolidCube(1)
    glPopMatrix()

    # Wheels of the car (using cylinders)
    wheel_positions = [
        (-2, -3, 3), (2, -3, 3),  # Front wheels
        (-2, 3, 3), (2, 3, 3)      # Back wheels
    ]
    glColor3f(0, 0, 0)  # Black color for wheels
    for pos in wheel_positions:
        glPushMatrix()
        glTranslatef(car_pos[0] + pos[0], pos[1], car_pos[1] + pos[2])
        glRotatef(car_angle, 0, 1, 0)
        gluCylinder(gluNewQuadric(), 1, 1, 2, 10, 10)  # Draw a cylinder as a wheel
        glPopMatrix()

def move_car():
    global car_pos, car_angle, car_speed, boost_bar
    if b'w' in keys and keys[b'w']:
        if boost_active and boost_bar > 0:
            car_speed = boost_speed
            boost_bar -= 0.5
        else:
            car_speed += acceleration
            car_speed = min(car_speed, max_speed)
    elif b's' in keys and keys[b's']:
        car_speed -= acceleration
    else:
        if car_speed > 0:
            car_speed -= friction
        elif car_speed < 0:
            car_speed += friction
        if abs(car_speed) < 0.01:
            car_speed = 0

    if b'a' in keys and keys[b'a']:
        car_angle += steer_angle
    if b'd' in keys and keys[b'd']:
        car_angle -= steer_angle

    # Move car
    rad = math.radians(car_angle)
    car_pos[0] += math.sin(rad) * car_speed
    car_pos[1] += math.cos(rad) * car_speed

    # Record for ghost
    recording_positions.append((car_pos[0], car_pos[1], car_angle))

def check_checkpoints():
    global checkpoint_passed, current_lap_time, best_lap_time, ghost_positions
    angle_rad = math.radians(360 / num_checkpoints * checkpoint_passed)
    cx = 100 * math.cos(angle_rad)
    cy = 100 * math.sin(angle_rad)
    dist = math.hypot(car_pos[0] - cx, car_pos[1] - cy)
    if dist < 10:
        checkpoint_passed += 1
        if checkpoint_passed >= num_checkpoints:
            checkpoint_passed = 0
            lap_time = time.time() - lap_start_time
            if best_lap_time is None or lap_time < best_lap_time:
                best_lap_time = lap_time
                ghost_positions.clear()
                ghost_positions.extend(recording_positions)
            reset_game()

def reset_game():
    global car_pos, car_angle, car_speed, boost_bar, checkpoint_passed, lap_start_time
    car_pos = [0.0, 0.0]
    car_angle = 0.0
    car_speed = 0.0
    boost_bar = 100
    checkpoint_passed = 0
    lap_start_time = time.time()

def showScreen():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()

    setupCamera()

    draw_track()
    draw_car()

    # Display HUD
    draw_text(10, 770, f"A Random Fixed Position Text")
    draw_text(10, 740, f"See how the position and variable change?: {rand_var}")

    # Lap time and speed display
    draw_text(10, 720, f"Lap Time: {round(current_lap_time, 2)}s")

    # Check if best_lap_time is None before rounding it
    best_lap_text = f"Best Lap: {round(best_lap_time, 2)}s" if best_lap_time is not None else "Best Lap: No lap recorded"
    draw_text(10, 690, best_lap_text)

    draw_text(850, 770, f"Speed: {round(abs(car_speed), 2)}")

    glutSwapBuffers()

def idle():
    global current_lap_time
    if not paused:
        move_car()
        check_checkpoints()
        current_lap_time = time.time() - lap_start_time
    glutPostRedisplay()

def keyboardListener(key, x, y):
    global boost_active
    keys[key] = True
    if key == b' ':
        boost_active = True
    if key == b'r':
        reset_game()
    if key == b'p':
        toggle_pause()

def keyboardUpListener(key, x, y):
    global boost_active
    keys[key] = False
    if key == b' ':
        boost_active = False

def specialKeyListener(key, x, y):
    pass

def mouseListener(button, state, x, y):
    pass

def toggle_pause():
    global paused
    paused = not paused

# ========== Main Program ==========

def init():
    glClearColor(0, 0.5, 1, 1)
    glEnable(GL_DEPTH_TEST)
    # Add cones randomly
    for _ in range(20):
        cones.append((random.randint(-180, 180), random.randint(-180, 180)))

glutInit()
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH)
glutInitWindowSize(800, 600)
glutCreateWindow(b"3D Car Rally Demo")

init()

glutDisplayFunc(showScreen)
glutIdleFunc(idle)
glutKeyboardFunc(keyboardListener)
glutKeyboardUpFunc(keyboardUpListener)
glutSpecialFunc(specialKeyListener)
glutMouseFunc(mouseListener)

glutMainLoop()
