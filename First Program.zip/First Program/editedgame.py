from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import time
import random

# --- Window settings ---
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

# --- Game State ---
score = 0
diamond_speed = 150
last_time = time.time()
paused = False
game_over = False

# --- Game Objects ---
catcher = {'x': 350, 'y': 50, 'width': 100, 'height': 20, 'color': (1.0, 1.0, 1.0)}
diamond = {'x': 400, 'y': 580, 'width': 20, 'height': 20, 'color': (1, 0, 1)}

# --- Button Areas (x, y, w, h) ---
buttons = {
    'restart': (50, 550, 40, 40),
    'pause':   (120, 550, 40, 40),
    'exit':    (190, 550, 40, 40)
}

# --- Utility Functions ---
def has_collided(a, b):
    return (
        a['x'] < b['x'] + b['width'] and
        a['x'] + a['width'] > b['x'] and
        a['y'] < b['y'] + b['height'] and
        a['y'] + a['height'] > b['y']
    )

def spawn_diamond():
    global diamond
    x = random.randint(50, WINDOW_WIDTH - 50)
    color = (random.random(), random.random(), random.random())
    diamond = {'x': x, 'y': WINDOW_HEIGHT, 'width': 20, 'height': 20, 'color': color}

def reset_game():
    global score, diamond_speed, paused, game_over, catcher
    score = 0
    diamond_speed = 150
    paused = False
    game_over = False
    catcher['color'] = (1.0, 1.0, 1.0)
    catcher['x'] = 350
    spawn_diamond()
    print("Starting Over")

# --- Midpoint Line Drawing ---
def draw_line(x1, y1, x2, y2):
    dx = abs(x2 - x1)
    dy = abs(y2 - y1)
    x, y = x1, y1
    sx = 1 if x2 > x1 else -1
    sy = 1 if y2 > y1 else -1

    if dx > dy:
        err = dx / 2.0
        while x != x2:
            glVertex2i(int(x), int(y))
            err -= dy
            if err < 0:
                y += sy
                err += dx
            x += sx
    else:
        err = dy / 2.0
        while y != y2:
            glVertex2i(int(x), int(y))
            err -= dx
            if err < 0:
                x += sx
                err += dy
            y += sy
    glVertex2i(int(x), int(y))

# --- Drawing Game Objects ---
def draw_rect_box(x, y, w, h):
    draw_line(x, y, x + w, y)
    draw_line(x + w, y, x + w, y + h)
    draw_line(x + w, y + h, x, y + h)
    draw_line(x, y + h, x, y)

def draw_diamond():
    glColor3f(*diamond['color'])
    cx, cy = diamond['x'], diamond['y']
    size = 10
    draw_line(cx, cy + size, cx + size, cy)
    draw_line(cx + size, cy, cx, cy - size)
    draw_line(cx, cy - size, cx - size, cy)
    draw_line(cx - size, cy, cx, cy + size)

def draw_catcher():
    glColor3f(*catcher['color'])
    x, y = catcher['x'], catcher['y']
    w, h = catcher['width'], catcher['height']
    draw_line(x, y, x + w, y)
    draw_line(x + w, y, x + w - 20, y + h)
    draw_line(x + w - 20, y + h, x + 20, y + h)
    draw_line(x + 20, y + h, x, y)

def draw_buttons():
    # Restart Button (Teal Arrow)
    glColor3f(0, 1, 1)
    x, y, w, h = buttons['restart']
    draw_line(x + 30, y + 30, x + 10, y + 20)
    draw_line(x + 10, y + 20, x + 30, y + 10)

    # Pause/Play Button (Amber)
    glColor3f(1, 0.75, 0)
    x, y, w, h = buttons['pause']
    if paused:
        draw_line(x + 10, y + 10, x + 30, y + 20)
        draw_line(x + 30, y + 20, x + 10, y + 30)
    else:
        draw_line(x + 12, y + 10, x + 12, y + 30)
        draw_line(x + 26, y + 10, x + 26, y + 30)

    # Exit Button (Red X)
    glColor3f(1, 0, 0)
    x, y, w, h = buttons['exit']
    draw_line(x + 10, y + 10, x + 30, y + 30)
    draw_line(x + 30, y + 10, x + 10, y + 30)

# --- Update Function ---
def update():
    global last_time, diamond, score, diamond_speed, game_over

    current_time = time.time()
    delta = current_time - last_time
    last_time = current_time

    if not paused and not game_over:
        diamond['y'] -= diamond_speed * delta

        if has_collided(diamond, catcher):
            score += 1
            print("Score:", score)
            diamond_speed += 10
            spawn_diamond()
        elif diamond['y'] + diamond['height'] < 0:
            game_over = True
            catcher['color'] = (1.0, 0.0, 0.0)
            print("Game Over. Final Score:", score)

    glutPostRedisplay()

# --- Display Function ---
def display():
    glClear(GL_COLOR_BUFFER_BIT)
    glLoadIdentity()
    glBegin(GL_POINTS)

    draw_diamond()
    draw_catcher()
    draw_buttons()

    glEnd()
    glFlush()

# --- Keyboard Movement ---
def special_keys(key, x, y):
    if paused or game_over:
        return
    if key == GLUT_KEY_LEFT and catcher['x'] > 0:
        catcher['x'] -= 20
    elif key == GLUT_KEY_RIGHT and catcher['x'] + catcher['width'] < WINDOW_WIDTH:
        catcher['x'] += 20

# --- Mouse Clicks for Buttons ---
def mouse(button, state, x, y):
    global paused
    if button == GLUT_LEFT_BUTTON and state == GLUT_DOWN:
        y = WINDOW_HEIGHT - y
        for name, (bx, by, bw, bh) in buttons.items():
            if bx <= x <= bx + bw and by <= y <= by + bh:
                if name == 'restart':
                    reset_game()
                elif name == 'pause':
                    paused = not paused
                elif name == 'exit':
                    print("Goodbye. Final Score:", score)
                    glutLeaveMainLoop()

# --- Setup and Run ---
def main():
    glutInit()
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB)
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT)
    glutInitWindowPosition(100, 100)
    glutCreateWindow(b"Catch the Diamonds!")

    glClearColor(0, 0, 0, 1)
    gluOrtho2D(0, WINDOW_WIDTH, 0, WINDOW_HEIGHT)

    reset_game()

    glutDisplayFunc(display)
    glutIdleFunc(update)
    glutSpecialFunc(special_keys)
    glutMouseFunc(mouse)

    glutMainLoop()

if __name__ == '__main__':
    main()