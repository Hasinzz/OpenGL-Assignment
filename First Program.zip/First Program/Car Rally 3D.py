### Full 3D Car Rally Demo (inside the template)
### By following your requested structure

from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import math
import random
import time

# Global Variables
angle = 0.0
camera_angle = 0.0
cameraHeight = 50
cameraDistance = 200

# Car properties
car_x = 0
car_y = 0
car_angle = 0  # Car facing direction
car_speed = 0.0
max_speed = 2.0
acceleration = 0.05
friction = 0.02
steer_angle = 3

# Nitro Boost
boost_active = False
boost_bar = 100  # full = 100
boost_speed = 4.0

# Lap and checkpoints
global lap_start_time
lap_start_time = time.time()
current_lap_time = 0
best_lap_time = None
checkpoint_passed = 0
num_checkpoints = 5



# Ghost Car (simple)
ghost_positions = []  # list of (x, y, angle)
recording_positions = []
show_ghost = False

# Game state
paused = False

# Key States
keys = {}

# Environment decorations
cones = []

# ========== Helper Functions ==========

def draw_car():
    glPushMatrix()
    glTranslatef(car_x, 0, car_y)
    glRotatef(car_angle, 0, 1, 0)
    glScalef(5, 2, 8)  # Car size
    glColor3f(1, 0, 0)
    glutSolidCube(1)
    glPopMatrix()

def draw_ghost_car():
    if not show_ghost or not ghost_positions:
        return
    glColor3f(0, 1, 1)
    for (gx, gy, ga) in ghost_positions:
        glPushMatrix()
        glTranslatef(gx, 0.1, gy)
        glRotatef(ga, 0, 1, 0)
        glScalef(5, 2, 8)
        glutWireCube(1)
        glPopMatrix()

def draw_track():
    glColor3f(0.2, 0.8, 0.2)
    glBegin(GL_QUADS)
    glVertex3f(-200, -1, -200)
    glVertex3f(200, -1, -200)
    glVertex3f(200, -1, 200)
    glVertex3f(-200, -1, 200)
    glEnd()
    
    # Checkpoints
    for i in range(num_checkpoints):
        angle_rad = math.radians(360 / num_checkpoints * i)
        cx = 100 * math.cos(angle_rad)
        cy = 100 * math.sin(angle_rad)
        glPushMatrix()
        glTranslatef(cx, 0, cy)
        glScalef(10, 1, 2)
        glColor3f(1, 1, 0)
        glutSolidCube(1)
        glPopMatrix()

def draw_cones():
    for (x, y) in cones:
        glPushMatrix()
        glTranslatef(x, 0, y)
        glColor3f(1, 0.5, 0)
        glutSolidCone(1, 3, 10, 2)
        glPopMatrix()

def draw_HUD():
    glColor3f(1, 1, 1)
    glWindowPos2d(10, 580)
    text = f"Speed: {round(abs(car_speed), 2)} | Lap Time: {round(current_lap_time, 2)}"
    for ch in text:
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, ord(ch))
    
    glWindowPos2d(10, 550)
    if best_lap_time:
        best = f"Best Lap: {round(best_lap_time, 2)}s"
        for ch in best:
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, ord(ch))
    
    glWindowPos2d(10, 520)
    boost_txt = f"Boost: {boost_bar}%"
    for ch in boost_txt:
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, ord(ch))

def reset_game():
    global car_x, car_y, car_angle, car_speed, boost_bar, checkpoint_passed, lap_start_time
    car_x = car_y = car_angle = car_speed = 0
    boost_bar = 100
    checkpoint_passed = 0
    lap_start_time = time.time()

def check_checkpoints():
    global checkpoint_passed, current_lap_time, best_lap_time, ghost_positions
    angle_rad = math.radians(360 / num_checkpoints * checkpoint_passed)
    cx = 100 * math.cos(angle_rad)
    cy = 100 * math.sin(angle_rad)
    dist = math.hypot(car_x - cx, car_y - cy)
    if dist < 10:
        checkpoint_passed += 1
        if checkpoint_passed >= num_checkpoints:
            checkpoint_passed = 0
            lap_time = time.time() - lap_start_time
            if best_lap_time is None or lap_time < best_lap_time:
                best_lap_time = lap_time
                ghost_positions.clear()
                ghost_positions.extend(recording_positions)
            reset_game()

def move_car():
    global car_x, car_y, car_angle, car_speed, boost_bar
    # Handle keys
    if b'w' in keys and keys[b'w']:
        if boost_active and boost_bar > 0:
            car_speed = boost_speed
            boost_bar -= 0.5
        else:
            car_speed += acceleration
            car_speed = min(car_speed, max_speed)
    elif b's' in keys and keys[b's']:
        car_speed -= acceleration
    else:
        # Apply friction
        if car_speed > 0:
            car_speed -= friction
        elif car_speed < 0:
            car_speed += friction
        if abs(car_speed) < 0.01:
            car_speed = 0

    if b'a' in keys and keys[b'a']:
        car_angle += steer_angle
    if b'd' in keys and keys[b'd']:
        car_angle -= steer_angle

    # Move car
    rad = math.radians(car_angle)
    car_x += math.sin(rad) * car_speed
    car_y += math.cos(rad) * car_speed

    # Record for ghost
    recording_positions.append((car_x, car_y, car_angle))

def toggle_pause():
    global paused
    paused = not paused

# ========== GLUT Callbacks ==========

def draw():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glMatrixMode(GL_MODELVIEW)

    setupCamera()

    draw_track()
    draw_cones()
    draw_car()
    draw_ghost_car()

    glMatrixMode(GL_PROJECTION)
    glPushMatrix()
    glLoadIdentity()
    gluOrtho2D(0, 800, 0, 600)
    glMatrixMode(GL_MODELVIEW)
    glPushMatrix()
    glLoadIdentity()

    draw_HUD()

    glPopMatrix()
    glMatrixMode(GL_PROJECTION)
    glPopMatrix()
    glMatrixMode(GL_MODELVIEW)

    glutSwapBuffers()

def idle():
    global current_lap_time
    if not paused:
        move_car()
        check_checkpoints()
        current_lap_time = time.time() - lap_start_time
    glutPostRedisplay()

def keyboardListener(key, x, y):
    global boost_active
    keys[key] = True
    if key == b' ':  # Spacebar
        boost_active = True
    if key == b'r':
        reset_game()
    if key == b'p':
        toggle_pause()

def keyboardUpListener(key, x, y):
    global boost_active
    keys[key] = False
    if key == b' ':
        boost_active = False

def specialKeyListener(key, x, y):
    pass

def mouseListener(button, state, x, y):
    pass

def setupCamera():
    glLoadIdentity()
    gluLookAt(0, cameraHeight, cameraDistance, 0, 0, 0, 0, 1, 0)

# ========== Main Program ==========

def init():
    glClearColor(0, 0.5, 1, 1)
    glEnable(GL_DEPTH_TEST)
    # Add cones randomly
    for _ in range(20):
        cones.append((random.randint(-180, 180), random.randint(-180, 180)))

glutInit()
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH)
glutInitWindowSize(800, 600)
glutCreateWindow(b"3D Car Rally Demo")

init()

glutDisplayFunc(draw)
glutIdleFunc(idle)
glutKeyboardFunc(keyboardListener)
glutKeyboardUpFunc(keyboardUpListener)
glutSpecialFunc(specialKeyListener)
glutMouseFunc(mouseListener)


glutMainLoop()
